package org.example;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Set;

/* TODO This class generated for cookies but never used or initiated with existing project.
*   Possible to initiate with existing project to increase performance and store user behaviour data
*  */
public class Cookies {

    /* TODO Save cookies to a file
    *   possible usage in Main.java --> extractFullData method*/
    public static void saveCookies(WebDriver driver, String filePath) {
        Set<Cookie> cookies = driver.manage().getCookies();
        try {
            FileOutputStream fileOut = new FileOutputStream(filePath);
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(cookies);
            objectOut.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /* TODO Load cookies from a file
    *   --> possible usage in Main.java --> main method*/
    public static void loadCookies(WebDriver driver, String filePath) {
        try {
            FileInputStream fileIn = new FileInputStream(filePath);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            Set<Cookie> cookies = (Set<Cookie>) objectIn.readObject();
            objectIn.close();
            for (Cookie cookie : cookies) {
                driver.manage().addCookie(cookie);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /* TODO Check for existing cookies
    *   --> possible usage in Main.java --> main method before loadCookies method */
    public static boolean cookiesExist(WebDriver driver) {
        Set<Cookie> cookies = driver.manage().getCookies();
        return !cookies.isEmpty();
    }
}

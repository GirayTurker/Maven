package org.example;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;


//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) throws IOException {

        /* DEVELOPMENT BLOCK
        // Start the timer
        long startTime = System.nanoTime();
        */

        //Main URL
        String url = "https://www.cochranelibrary.com/cdsr/reviews/topics";

        //Main URL elements
        //Changing these properties along with others that they defined inside the methods can allow to use the project for other websites
        String query1= "li.browse-by-list-item";
        String query11="a";
        String attrKey1="href";

        List<Map<String, String>> extractedData = visitAndExtractUrls(url,query1,query11,attrKey1);

        // Initial list to store Final data
        List<String> finalData = new ArrayList<>();

        // Process and extract data
        extractAndProcessMain(extractedData, finalData);

        // Write finalData to a .txt file
        // this is section for write the whole Review list for all topics stored in finalData
//        writeToFile(finalData);


        /* DEVELOPMENT BLOCK
        long endTime = System.nanoTime(); // End the timer

        // Print the contentList
        System.out.println("Content List:");
        for (String content : finalData) {
            System.out.println(content);
        }

        // Calculate the elapsed time
        long durationMs = (endTime - startTime) / 1_000_000;

        //INFO
        System.out.println(STR."From \{extractedData.size()} topic \{finalData.size()} review extract with \{durationMs} millisecond");
        System.out.println("-------------------------");
        */

    }

    /*
    TODO Method for combine Each topic Header and related url O(n) complexity
      --> extractFullData method using inside of this method
    */
    private static void extractAndProcessMain(List<Map<String, String>> extractedData, List<String> finalData) {
        List<String> contentList;

        // Print the extracted data
        for (Map<String, String> data : extractedData) {
            String urls = data.get("Url");
            String topic = data.get("Topic");

            //Print the topic and related url before topic reviews data extraction
            System.out.println(STR."Topic: \{topic}");
            System.out.println(STR."URL: \{urls}");

            // Possible to extract data for only desired Topic and related Reviews

            // Run extractFullData asynchronously
            CompletableFuture<List<String>> futureContentList = CompletableFuture.supplyAsync(() -> extractFullData(urls));

            // Wait for the completion of the future and get the result
            contentList = futureContentList.join();

            // Add topic at the beginning of each line in contentList and store it in finalData
            // Defined development at upper line changed with: contList is not add any additional data to finalData List.
            for (String content : contentList) {
                finalData.add(STR."\{content}");
            }
            //Write extracted topic reviews to the file after visiting each topic
            try {
                writeToFile(finalData, topic);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /* TODO Method for extract URLs from each visited Topic
         if each page contains m elements, the overall time complexity would be O(m⋅p), where p is the number of pages.
             --> contentList store Reviews for each Topic
    */
    private static List<String> extractFullData(String url) {

        //IMPORTANT !!!!!
        //Download chromedriver.exe based on Chrome browser version, extract file and insert the absolute file path!!
        String chromedriverPath = "";

        // List to store the extracted Topic > Reviews content
        List<String> fullUrls = new ArrayList<>();
        // Web Driver
        WebDriver driver = initializeChromeDriverAndOpenUrl(chromedriverPath,url);

        //Bool value for pagination
        boolean hasNextPage = true;

        //Possible to add extra info inside this block.
        //Such as total Reviews for each topic or comparison between extracted Reviews and actual reviews that they carried in website or time spend to extracted data for each topic reviews
            do {
                List<WebElement> elements = driver.findElements(By.cssSelector("div.search-results-item-body"));
                for (WebElement element : elements) {
                    // Create WebDriverWait object inside the loop for wait page load or 10 sec.
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                    // Find the individual elements within each <div class="search-results-item-body">
                    // Find the <a> element within <h3 class="result-title">
                    WebElement anchorElement = element.findElement(By.cssSelector("h3.result-title a"));
                    // Extract href attribute value
                    String href = anchorElement.getAttribute("href");
                    WebElement titleElement = element.findElement(By.cssSelector("h3.result-title a"));
                    WebElement authorsElement = element.findElement(By.cssSelector("div.search-result-authors div"));
                    WebElement dateElement = element.findElement(By.cssSelector("div.search-result-metadata-item div.search-result-date div"));
                    WebElement topicElement = element.findElement(By.xpath("//*[@id=\"facetDisplaySection\"]/ul/li/ul/li/span/a"));

                    // Extract text from each element
                    String title = titleElement.getText();
                    String authors = authorsElement.getText();
                    String date = dateElement.getText();
                    String topic = topicElement.getText();

                    // Build the string with all extracted information
                    // \n end of the definition to give space(Currently closed for development purposes)
                    String extractedData = STR."\{topic} | \{href} | \{title} | \{authors} | \{date}";

                    // Print and add to the list
                    System.out.println(extractedData);

                    //Add desired Topic > Reviews info to the List
                    fullUrls.add(extractedData);
                }

                //Pagination block
                //Possible to add extra info, such as visited pages number for each Topic
                // Check if the next link exists
                List<WebElement> nextLinks = driver.findElements(By.cssSelector("#column-2 > div.search-results-footer > div > div.pagination-next-link > a"));
                if (nextLinks.isEmpty()) {
                    System.out.println("Next link not found. Exiting loop.");
                    hasNextPage = false;
                } else {
                    for (WebElement nextLink : nextLinks) {
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", nextLink);

                        // Wait for the next page content to load
                        try {
                            Thread.sleep(5000); // Adjust the wait time as needed
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    try {
                        Thread.sleep(5000); // Adjust the wait time as needed
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            while (hasNextPage);

        driver.quit();
        return fullUrls;
    }

    //TODO Method for visit main URL, extract Topic Header and Topic Url -  O(n) complexity
    private static List<Map<String, String>> visitAndExtractUrls(String mainUrl, String cssQuery, String cssQuery2,String attrKey) {
        List<Map<String, String>> extractedData = new ArrayList<>();
        Document doc;
        try {

            // Fetch HTML content from the main URL
            doc = Jsoup.connect(mainUrl).get();

            // Select elements using a CSS query
            Elements browseListItems = doc.select(cssQuery);

            // Iterate over selected elements
            for (Element item : browseListItems) {
                // Extract data from the item
                String href = item.select(cssQuery2).attr(attrKey);
                String topic = item.select(cssQuery2).text();

                //System.out.println(topic);
                // Create a map to store the extracted data
                Map<String, String> dataMap = new HashMap<>();
                dataMap.put("Url", href);
                dataMap.put("Topic", topic);

                // Add the map to the list of extracted data
                extractedData.add(dataMap);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return extractedData;
    }



    /* TODO Method File Writer - O(n) complexity
    *   ex format to create new .txt file: 08_29_24_2_40_PM.txt
    */
    private static void writeToFile(List<String> finalData, String topic) throws IOException {
        // Get current date and time
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM_dd_yy_h_mm_a");
        String currentTime = dateFormat.format(new Date());

        String fileName = STR."\{topic}_\{currentTime}.txt";

        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(fileName));
            // Write finalData to the file
            for (String line : finalData) {
                writer.write(line);
                writer.newLine();
            }
            System.out.println(STR."Data has been written to \{fileName}");
        }
        finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    /* TODO Method for Open chromedriver.exe O(n) complexity
     *   chromedriver is open and close browser in background
     *   for observe the sequence,
     *   replace Initialize ChromeDriver with WebDriver driver = new ChromeDriver();
     *  --> chromedriverPath should change based on chromedriver.exe location
     *  --> Download chromedriver fallow given instructions: https://chromedriver.chromium.org/downloads
     */

    public static WebDriver initializeChromeDriverAndOpenUrl(String chromedriverPath, String url) {
        // Set the path to chromedriver
        System.setProperty("webdriver.chrome.driver", chromedriverPath);

        //chromedriver headless option
        //browser works on the background
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");

        // Initialize ChromeDriver
        WebDriver driver = new ChromeDriver(options);

        // Open the URL in a new browser window
        driver.get(url);

        return driver;
    }

}